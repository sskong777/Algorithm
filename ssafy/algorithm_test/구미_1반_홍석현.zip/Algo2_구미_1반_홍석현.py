# T = int(input())    # 테스트케이스 갯수 입력
# for tc in range(1, T+1):    # 테스트케이스 만큼 반복
arr = []    #N차원 리스트를 담아줄 arr배열 선언
N = int(input())
for n in range(N):  # N만큼 반복하여 arr 배열에 입력받은 값을 담아준다.
    arr.append(list(map(int, input().split())))

total_dir = []  # 4방향 합을 구해줄 배열 선언
total_3x3 = []  # 3x3 배열의 합을 구해줄 배열 선언
max_dir = 0 #4방향 합의 최대값을 구해줄 변수 선언 및 초기화
max_3x3 = 0 #3x3 배열의 합의 최대값을 구해줄 변수 선언 및 초기화

for r in range(N):
    for c in range(N):
        total = 0

        # -2부터 2까지 1씩 증가하는 반복문으로 arr인덱스값을 이용하여 4방향 합을 total에 담아준다.
        # for i in range(-2,3,1):
        #     if r + i >= N or r+i < 0 or c + i >= N or c+i < 0:
        #
